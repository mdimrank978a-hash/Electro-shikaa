ইলেক্ট্রো শিক্ষা — Android অ্যাপ প্রজেক্ট (v1.1)
================================================

ফিচার:
- বাংলা Electrical/Electronics নোট
- kW↔kVA, kW↔W এবং single/three-phase current calculator
- 4-band resistor calculator
- Cable size helper (illustrative estimates with prominent safety warnings)
- MCB rating helper (preliminary screening only; not a final design)
- Basic lessons and quiz
- AdMob test banner integration
- Modular HTML/JS structure to extend later

গুরুত্বপূর্ণ সীমাবদ্ধতা:
- এই ZIP source project; ready-to-install APK নয়।
- Cable/MCB calculators are educational preliminary helpers, NOT code-compliant engineering design. Results depend on installation method, ambient temperature, grouping, voltage drop, cable type, fault level, protective coordination and local standards. A qualified electrician/engineer must verify.
- kW to kVA requires power factor. Current calculators ask for PF and efficiency.
- AdMob uses Google's official test App ID and test banner ID. It earns no revenue. Before release, create your own AdMob app/ad unit IDs and implement consent/privacy requirements.
- For Google Play, review target SDK policy, privacy policy, Data safety form, ads declaration, content rating, app signing, and all current Play Console requirements.
- Project uses Android Gradle Plugin 8.7.3, compile/target SDK 35, min SDK 23. An appropriate Android SDK/JDK and Gradle setup is needed.

Build:
1. Open project folder in Android Studio or a compatible Android build environment.
2. Sync Gradle and build/run.
3. Test all calculators and WebView behavior on devices.
4. For release, create a signed Android App Bundle (.aab), not just a debug APK.
